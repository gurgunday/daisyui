import{a as t}from"../chunks/entry.DZAhBuFN.js";export{t as start};
