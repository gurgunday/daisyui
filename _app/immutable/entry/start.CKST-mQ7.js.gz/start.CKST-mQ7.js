import{a as t}from"../chunks/entry.BBGh5Zja.js";export{t as start};
